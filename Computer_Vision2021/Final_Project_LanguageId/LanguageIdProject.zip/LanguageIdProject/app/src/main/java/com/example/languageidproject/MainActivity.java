package com.example.languageidproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.nl.languageid.IdentifiedLanguage;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
//import com.google.mlkit.samples.languageid.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView outputText;
    private static final String TAG = "MainActivity";
    private LanguageIdentifier languageIdentification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        final TextInputEditText inputText = findViewById(R.id.inputText);
        Button idLanguageButton = findViewById(R.id.buttonIdLanguage);
        Button findAllButton = findViewById(R.id.buttonIdAll);
        outputText = findViewById(R.id.outputText);

        languageIdentification = LanguageIdentification.getClient();
        // Any new instances of LanguageIdentification needs to be closed appropriately.
        // LanguageIdentification automatically calls close() on the ON_DESTROY lifecycle event,
        // so here we can add our languageIdentification instance as a LifecycleObserver for this
        // activity and have it be closed when this activity is destroyed.
        getLifecycle().addObserver(languageIdentification);

        idLanguageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = inputText.getText().toString();
                if (input.isEmpty()) {
                    Toast.makeText(
                            MainActivity.this, "You didn't type anything!",
                            Toast.LENGTH_SHORT)
                            .show();
                    return;
                }
                inputText.getText().clear();
                identifyLanguage(input);
            }
        });

        findAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = inputText.getText().toString();
                if (input.isEmpty()) {
                    Toast.makeText(
                            MainActivity.this, "You didn't type anything!",
                            Toast.LENGTH_SHORT)
                            .show();
                    return;
                }
                inputText.getText().clear();
                identifyPossibleLanguages(input);
            }
        });
    }
    private void identifyLanguage(final String inputText) {
        languageIdentification
                .identifyLanguage(inputText)
                .addOnSuccessListener(
                        this,
                        new OnSuccessListener<String>() {
                            @Override
                            public void onSuccess(String s) {
                                String preShow = String.format(
                                        Locale.US,
                                        "%s: %s",
                                        inputText,
                                        s);
                                if (preShow.contains("und")) {
                                    outputText.setText(inputText+": Undefined Language");
                                }
                                else {
                                    outputText.setText(preShow);
                                }
//                                outputText.append(
//                                        String.format(
//                                                Locale.US,
//                                                "\n%s - %s",
//                                                inputText,
//                                                s));
                                Toast.makeText(
                                        MainActivity.this, R.string.language_id_success,
                                        Toast.LENGTH_SHORT)
                                        .show();
                            }
                        })
                .addOnFailureListener(
                        this,
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                //Log.e(TAG, "Language identification error", e);
                                Toast.makeText(
                                        MainActivity.this, R.string.language_id_error,
                                        Toast.LENGTH_SHORT)
                                        .show();
                            }
                        });
    }

    private void identifyPossibleLanguages(final String inputText) {
        languageIdentification = LanguageIdentification.getClient();
        languageIdentification
                .identifyPossibleLanguages(inputText)
                .addOnSuccessListener(
                        this,
                        new OnSuccessListener<List<IdentifiedLanguage>>() {


                            @Override
                            public void onSuccess(List<IdentifiedLanguage> identifiedLanguages) {
//                                List<String> detectedLanguages =
//                                        new ArrayList<>(identifiedLanguages.size());
//                                for (IdentifiedLanguage language : identifiedLanguages) {
//                                    System.out.println(language.getLanguageTag() + ":" + language.getConfidence()*100 +"%");
//                                    detectedLanguages.add(
//                                            String.format(
//                                                    Locale.US,
//                                                    "%s: %s\n",
//                                                    language.getLanguageTag(),
//                                                    (language.getConfidence()*100) +"%")
//                                    );
//                                }
                                List<String> detectedLanguages =
                                        new ArrayList<>(3);
                                IdentifiedLanguage detectedLanguagesMax = identifiedLanguages.get(0);
                                IdentifiedLanguage detectedSecLanguagesMax = identifiedLanguages.get(0);
                                IdentifiedLanguage detectedThirdLanguagesMax = identifiedLanguages.get(0);
                                if (identifiedLanguages.size()>=3) {
                                    detectedSecLanguagesMax = identifiedLanguages.get(1);
                                    detectedThirdLanguagesMax = identifiedLanguages.get(2);
                                }
                                else if (identifiedLanguages.size()==2) {
                                    detectedSecLanguagesMax = identifiedLanguages.get(1);
                                    detectedThirdLanguagesMax = identifiedLanguages.get(1);
                                }
                                detectedLanguages.add(String.format(
                                        Locale.US,
                                        "%s: %s\n",
                                        detectedLanguagesMax.getLanguageTag(),
                                        (detectedLanguagesMax.getConfidence()*100) +"%")
                                );
                                detectedLanguages.add(String.format(
                                        Locale.US,
                                        "%s: %s\n",
                                        detectedSecLanguagesMax.getLanguageTag(),
                                        (detectedSecLanguagesMax.getConfidence()*100) +"%")
                                );
                                detectedLanguages.add(String.format(
                                        Locale.US,
                                        "%s: %s\n",
                                        detectedThirdLanguagesMax.getLanguageTag(),
                                        (detectedThirdLanguagesMax.getConfidence()*100) +"%")
                                );


                                for (IdentifiedLanguage language : identifiedLanguages) {
                                    System.out.println("Max: " + detectedLanguagesMax.getLanguageTag()
                                            + ":" + detectedLanguagesMax.getConfidence()*100 +"%");
                                    System.out.println("Second Max: " + detectedSecLanguagesMax.getLanguageTag()
                                            + ":" + detectedSecLanguagesMax.getConfidence()*100 +"%");
                                    System.out.println("Third Max: " + detectedThirdLanguagesMax.getLanguageTag()
                                            + ":" + detectedThirdLanguagesMax.getConfidence()*100 +"%");
                                    System.out.println("Current Language: " + language.getLanguageTag() + ":" + language.getConfidence()*100 +"%");
                                    if (language.getConfidence() > detectedLanguagesMax.getConfidence()) {
                                        detectedThirdLanguagesMax = detectedSecLanguagesMax;
                                        detectedSecLanguagesMax = detectedLanguagesMax;
                                        detectedLanguagesMax = language;
                                        detectedLanguages.set(0,
                                                String.format(
                                                        Locale.US,
                                                        "%s: %s\n",
                                                        detectedLanguagesMax.getLanguageTag(),
                                                        (detectedLanguagesMax.getConfidence()*100) +"%")
                                        );
                                        detectedLanguages.set(1,
                                                String.format(
                                                        Locale.US,
                                                        "%s: %s\n",
                                                        detectedSecLanguagesMax.getLanguageTag(),
                                                        (detectedSecLanguagesMax.getConfidence()*100) +"%")
                                        );
                                        detectedLanguages.set(2,
                                                String.format(
                                                        Locale.US,
                                                        "%s: %s\n",
                                                        detectedThirdLanguagesMax.getLanguageTag(),
                                                        (detectedThirdLanguagesMax.getConfidence()*100) +"%")
                                        );
                                    }
                                    else if (detectedLanguagesMax.getConfidence() > language.getConfidence()
                                            && language.getConfidence() > detectedSecLanguagesMax.getConfidence()) {
                                        detectedThirdLanguagesMax = detectedSecLanguagesMax;
                                        detectedSecLanguagesMax = language;
                                        detectedLanguages.set(1,
                                                String.format(
                                                        Locale.US,
                                                        "%s: %s\n",
                                                        detectedSecLanguagesMax.getLanguageTag(),
                                                        (detectedSecLanguagesMax.getConfidence()*100) +"%")
                                        );
                                        detectedLanguages.set(2,
                                                String.format(
                                                        Locale.US,
                                                        "%s: %s\n",
                                                        detectedThirdLanguagesMax.getLanguageTag(),
                                                        ( detectedThirdLanguagesMax.getConfidence()*100) +"%")
                                        );
                                    }
                                    else if (detectedSecLanguagesMax.getConfidence() >  language.getConfidence()
                                            && language.getConfidence() > detectedThirdLanguagesMax.getConfidence()) {
                                        detectedThirdLanguagesMax = language;
                                        detectedLanguages.set(2,
                                                String.format(
                                                        Locale.US,
                                                        "%s: %s\n",
                                                        detectedThirdLanguagesMax.getLanguageTag(),
                                                        (detectedThirdLanguagesMax.getConfidence()*100) +"%")
                                        );
                                    }
                                }
                                String preShow="";
                                if (detectedLanguages.get(0).equals(detectedLanguages.get(1))
                                        && detectedLanguages.get(1).equals(detectedLanguages.get(2))) {
                                    preShow = String.format(
                                            Locale.US,
                                            "%s: \n%s",
                                            inputText,
                                            detectedLanguages.get(0));
                                }
                                else if (detectedLanguages.get(0).equals(detectedLanguages.get(1))) {
                                    preShow = String.format(
                                            Locale.US,
                                            "%s: \n%s\n%s",
                                            inputText,
                                            detectedLanguages.get(1),
                                            detectedLanguages.get(2));
                                }
                                else if (detectedLanguages.get(1).equals(detectedLanguages.get(2))) {
                                    preShow = String.format(
                                            Locale.US,
                                            "%s: \n%s\n%s",
                                            inputText,
                                            detectedLanguages.get(0),
                                            detectedLanguages.get(1));
                                }
                                else {
                                    preShow = String.format(
                                        Locale.US,
                                        "%s: \n%s",
                                        inputText,
                                        TextUtils.join("", detectedLanguages));
                                }
                                for(int i=0; i<detectedLanguages.size(); i++) {
                                    System.out.println(i + " " + detectedLanguages.get(i));
                                }
                                outputText.setText(preShow);
//                                outputText.append(
//                                        String.format(
//                                                Locale.US,
//                                                "\n%s - [%s]",
//                                                inputText,
//                                                TextUtils.join(", ", detectedLanguages)));
                                Toast.makeText(
                                        MainActivity.this, R.string.language_id_success,
                                        Toast.LENGTH_SHORT)
                                        .show();
                            }
                        })
                .addOnFailureListener(
                        this,
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                //Log.e(TAG, "Language identification error", e);
                                Toast.makeText(
                                        MainActivity.this, R.string.language_id_error,
                                        Toast.LENGTH_SHORT)
                                        .show();
                            }
                        });
    }

}