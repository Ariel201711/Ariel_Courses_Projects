package com.journaldev.recyclerviewcardview;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    private FirebaseAuth mAuth;
    // not so acceptable!
    private Register myRegisterContext;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

    }


    public void moveToRecyclerViewFromRegister(View view) {
        //Button registerButtonFromLogin = findViewById(R.id.registerButtonFromLogin);
        if (createUser()) {
            Intent intent = new Intent(Register.this, RecyclerView.class);
            this.finish();
            startActivity(intent);
        }
    }

    public boolean createUser() {
        EditText userNameFromEditText = findViewById(R.id.userNameRegister);
        EditText passwordFromEditText02 = findViewById(R.id.passwordRegister);
        // email is the default, but we can use userName instead
        String userName = userNameFromEditText.getText().toString();
        String password = passwordFromEditText02.getText().toString();
        final boolean[] registered = {false};
        mAuth.createUserWithEmailAndPassword(userName, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            // EmailPasswordActivity - current Activity:
                            // in this case it is register
                            Toast.makeText(Register.this, "Authentication Successful.",
                                    Toast.LENGTH_SHORT).show();
                            registered[0] = true;
                            Intent intent = new Intent(Register.this, RecyclerView.class);
                            myRegisterContext.finish();
                            startActivity(intent);
                        } else {
                            // If sign in fails, display a message to the user.

                            Toast.makeText(Register.this, "Authentication Failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        return registered[0];
    }
}