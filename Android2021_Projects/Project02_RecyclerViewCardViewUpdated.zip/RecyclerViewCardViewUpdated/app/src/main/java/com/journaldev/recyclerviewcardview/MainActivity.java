package com.journaldev.recyclerviewcardview;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.concurrent.Executor;

/*
Hence a RecyclerView is more customisable when compared to ListView and gives greater control to the users.
 */

public class MainActivity extends AppCompatActivity {

    static View.OnClickListener myOnClickListener;
    private FirebaseAuth mAuth;
    private Executor executor;
    private BiometricPrompt biometricPrompt;
    // not so acceptable!
    private MainActivity myContext;

    @RequiresApi(api = Build.VERSION_CODES.P)

    /*
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            reload();
        }
    }
    */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.login); // the content from the wanted screen
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        this.myContext = new MainActivity();
        executor = ContextCompat.getMainExecutor(this);
        biometricPrompt = new BiometricPrompt(this, executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationError(int errorCode,
                                                      @NonNull CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        Toast.makeText(getApplicationContext(),
                                "Authentication error: " + errString, Toast.LENGTH_SHORT)
                                .show();
                    }

                    @Override
                    public void onAuthenticationSucceeded(
                            @NonNull BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        Toast.makeText(getApplicationContext(),
                                "Authentication succeeded!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, RecyclerView.class);
                        myContext.finish();
                        startActivity(intent);
                    }

                    @Override
                    public void onAuthenticationFailed() {
                        super.onAuthenticationFailed();
                        Toast.makeText(getApplicationContext(), "Authentication failed",
                                Toast.LENGTH_SHORT)
                                .show();
                    }
                });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Biometric login for my app")
                .setSubtitle("Log in using your biometric credential")
                .setNegativeButtonText("Use account password")
                .build();

        // Prompt appears when user clicks "Log in".
        // Consider integrating with the keystore to unlock cryptographic operations,
        // if needed by your app.

        Button biometricLoginButton = findViewById(R.id.fingerPrintLoginButton);
        biometricLoginButton.setOnClickListener(view -> {
            biometricPrompt.authenticate(promptInfo);
        });
       // biometricPrompt.authenticate(promptInfo);

    }

    public void moveToRegister(View view) {
        //Button registerButtonFromLogin = findViewById(R.id.registerButtonFromLogin);
        Intent intent = new Intent(MainActivity.this, Register.class);
        this.finish();
        startActivity(intent);
    }

    public void moveToRecyclerViewFromMain(View view) {
        //Button registerButtonFromLogin = findViewById(R.id.registerButtonFromLogin);
        if(login()) {
            Intent intent = new Intent(MainActivity.this, RecyclerView.class);
            this.finish();
            startActivity(intent);
        }
    }

    public boolean login() {
        EditText userNameFromEditText = findViewById(R.id.usernameLogin);
        EditText passwordFromEditText02 = findViewById(R.id.passwordLogin);
        // email is the default, but we can use userName instead
        String userName = userNameFromEditText.getText().toString();
        String password = passwordFromEditText02.getText().toString();
        final boolean[] loggedIn = {false};
        mAuth.signInWithEmailAndPassword(userName, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            // If sign in fails, display a message to the user.
                            // EmailPasswordActivity - current Activity:
                            // in this case it is main activity
                            Toast.makeText(MainActivity.this, "sign In Successful.",
                                    Toast.LENGTH_SHORT).show();
                            loggedIn[0] = true;
                        } else {

                            Toast.makeText(MainActivity.this, "sign In Failed.",
                                    Toast.LENGTH_SHORT).show();

                        }
                    }
                });
        return loggedIn[0];
    }

}