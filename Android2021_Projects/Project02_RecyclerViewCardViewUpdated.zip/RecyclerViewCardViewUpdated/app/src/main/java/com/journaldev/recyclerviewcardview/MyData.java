package com.journaldev.recyclerviewcardview;



public class MyData {

    static String[] nameArray = {
            "Iron Man",
            "Captain America",
            "Thor",
            "Black Widow",
            "Hulk",
            "Black Panther",
            "Loki",
            "Star Lord",
            "Winter Soldier",
            "Scarlet Witch",
            "Hawk Eye",
            "Doctor Strange",
            "Vision",
            "Spider Man",
            "Ant Man",
            "Captain Marvel"
    };
    static String[] descriptionArray = {
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero",
            "a super hero"
    };

    static Integer[] drawableArray = {
            R.drawable.iron_man,
            R.drawable.captain_america,
            R.drawable.thor,
            R.drawable.black_widow,
            R.drawable.hulk,
            R.drawable.black_panther,
            R.drawable.loki,
            R.drawable.star_lord,
            R.drawable.winter_soldier,
            R.drawable.scarlet_witch,
            R.drawable.hawk_eye,
            R.drawable.doctor_strange,
            R.drawable.vision,
            R.drawable.spider_man,
            R.drawable.ant_man,
            R.drawable.captain_marvel
    };

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
}
