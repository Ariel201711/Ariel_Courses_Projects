package com.journaldev.recyclerviewcardview;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.util.ArrayList;

public class RecyclerView extends AppCompatActivity {

    private androidx.recyclerview.widget.RecyclerView recycleView;
    private androidx.recyclerview.widget.RecyclerView.LayoutManager layoutManager;
    private ArrayList<DataModel> data;
    private CustomAdapter adapter;
    static View.OnClickListener myOnClickListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itself_recycler_view);
        recycleView = findViewById(R.id.my_recicle_view);
        recycleView.hasFixedSize();
        layoutManager = new LinearLayoutManager(this);
        recycleView.setLayoutManager(layoutManager);
        recycleView.setItemAnimator(new DefaultItemAnimator());
        data =new ArrayList< DataModel>();

        for(int i=0 ; i<MyData.nameArray.length ; i++ )
        {
            data.add(new DataModel(MyData.nameArray[i],MyData.descriptionArray[i] , MyData.id_[i],MyData.drawableArray[i]));
        }
        adapter = new CustomAdapter(data);
        recycleView.setAdapter(adapter);
    }



}